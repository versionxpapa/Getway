package com.limited.khelobangladesh.reder;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import android.telephony.TelephonyManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.provider.Settings.Secure;
import java.util.concurrent.Semaphore;
import androidx.core.content.ContextCompat;
import androidx.core.app.NotificationCompat;
import android.os.AsyncTask;
import android.provider.Settings;

public class ShuvoHomeActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private double N1 = 0;
	private double Users = 0;
	private double GamingBalance = 0;
	private double WinningBalance = 0;
	private double GamingCoin = 0;
	private double WinningCoin = 0;
	private double N2 = 0;
	private double XeRoX = 0;
	private double Num1 = 0;
	private double Num2 = 0;
	private double Num3 = 0;
	private double Num4 = 0;
	private double Num5 = 0;
	private double Num6 = 0;
	private String m = "";
	private double bk = 0;
	
	private ArrayList<HashMap<String, Object>> UsersData = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> Matches = new ArrayList<>();
	private ArrayList<String> log = new ArrayList<>();
	
	private LinearLayout BG;
	private ListView listview1;
	private ScrollView Scroll;
	private LinearLayout SectionBG;
	private LinearLayout linear1;
	private ListView listview2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear10;
	private EditText edittext1;
	private Button button1;
	private LinearLayout linear11;
	private ListView listview3;
	private TextView textview1;
	private Button button2;
	private TextView textview2;
	private TextView textview3;
	private LinearLayout linear5;
	private CardView cardview3;
	private CardView cardview2;
	private CardView cardview1;
	private LinearLayout linear6;
	private ImageView imageview1;
	private LinearLayout linear7;
	private ImageView imageview2;
	private LinearLayout linear8;
	private ImageView imageview3;
	private LinearLayout B1;
	private LinearLayout B2;
	private TextView Tv1;
	private TextView Tv2;
	
	private AlertDialog.Builder SHUVO_DIALOG;
	private SharedPreferences SHUVO_ADMIN_SETTINGS;
	private Intent SHUVO_NEW_ACTIVITY = new Intent();
	private SharedPreferences SHUVO_MATCH_TYPE;
	private DatabaseReference Shuvo_Used = _firebase.getReference("Shuvo_Used69x");
	private ChildEventListener _Shuvo_Used_child_listener;
	private AlertDialog.Builder d;
	private AlertDialog.Builder X;
	private TimerTask t;
	private DatabaseReference XNXANIKPAY = _firebase.getReference("XNXANIKPAY");
	private ChildEventListener _XNXANIKPAY_child_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.shuvo_home);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		BG = findViewById(R.id.BG);
		listview1 = findViewById(R.id.listview1);
		Scroll = findViewById(R.id.Scroll);
		SectionBG = findViewById(R.id.SectionBG);
		linear1 = findViewById(R.id.linear1);
		listview2 = findViewById(R.id.listview2);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		linear10 = findViewById(R.id.linear10);
		edittext1 = findViewById(R.id.edittext1);
		button1 = findViewById(R.id.button1);
		linear11 = findViewById(R.id.linear11);
		listview3 = findViewById(R.id.listview3);
		textview1 = findViewById(R.id.textview1);
		button2 = findViewById(R.id.button2);
		textview2 = findViewById(R.id.textview2);
		textview3 = findViewById(R.id.textview3);
		linear5 = findViewById(R.id.linear5);
		cardview3 = findViewById(R.id.cardview3);
		cardview2 = findViewById(R.id.cardview2);
		cardview1 = findViewById(R.id.cardview1);
		linear6 = findViewById(R.id.linear6);
		imageview1 = findViewById(R.id.imageview1);
		linear7 = findViewById(R.id.linear7);
		imageview2 = findViewById(R.id.imageview2);
		linear8 = findViewById(R.id.linear8);
		imageview3 = findViewById(R.id.imageview3);
		B1 = findViewById(R.id.B1);
		B2 = findViewById(R.id.B2);
		Tv1 = findViewById(R.id.Tv1);
		Tv2 = findViewById(R.id.Tv2);
		SHUVO_DIALOG = new AlertDialog.Builder(this);
		SHUVO_ADMIN_SETTINGS = getSharedPreferences("SHUVO_ADMIN_SETTINGS", Activity.MODE_PRIVATE);
		SHUVO_MATCH_TYPE = getSharedPreferences("SHUVO_MATCH_TYPE", Activity.MODE_PRIVATE);
		d = new AlertDialog.Builder(this);
		X = new AlertDialog.Builder(this);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (m.equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Select Payment Method");
				} else {
					if (!edittext1.getText().toString().equals("")) {
						if (m.equals("bKash")) {
							if (edittext1.getText().toString().startsWith("You have received Tk ")) {
								SketchwareUtil.showMessage(getApplicationContext(), "আপনার ট্রানজেকশনটি সফলভাবে এড করা হয়েছে");
								try { 
									_addAutoBal(m, edittext1.getText().toString().trim());
									SketchwareUtil.showMessage(getApplicationContext(), "আপনার ট্রানজেকশনটি সফলভাবে এড করা হয়েছে..");
								}catch(Exception ex){ex.printStackTrace();}
							} else {
								SketchwareUtil.showMessage(getApplicationContext(), "❌️ আপনি ভুল ট্রানজেকশন আইডি দিয়েছেন ❌️");
							}
						}
						if (m.equals("NAGAD")) {
							if (edittext1.getText().toString().startsWith("Money Received.\nAmount: ")) {
								SketchwareUtil.showMessage(getApplicationContext(), "আপনার ট্রানজেকশনটি সফলভাবে এড করা হয়েছে");
								try { 
									_addAutoBal(m, edittext1.getText().toString().trim());
									SketchwareUtil.showMessage(getApplicationContext(), "আপনার ট্রানজেকশনটি সফলভাবে এড করা হয়েছে..");
								}catch(Exception ex){ex.printStackTrace();}
							} else {
								SketchwareUtil.showMessage(getApplicationContext(), "❌️ আপনি ভুল ট্রানজেকশন আইডি দিয়েছেন ❌️");
							}
						}
						if (m.equals("16216")) {
							if (edittext1.getText().toString().startsWith("Tk")) {
								SketchwareUtil.showMessage(getApplicationContext(), "আপনার ট্রানজেকশনটি সফলভাবে এড করা হয়েছে");
								try { 
									_addAutoBal(m, edittext1.getText().toString().trim());
									SketchwareUtil.showMessage(getApplicationContext(), "আপনার ট্রানজেকশনটি সফলভাবে এড করা হয়েছে..");
								}catch(Exception ex){ex.printStackTrace();}
							} else {
								SketchwareUtil.showMessage(getApplicationContext(), "❌️ আপনি ভুল ট্রানজেকশন আইডি দিয়েছেন ❌️");
							}
						}
					} else {
						((EditText)edittext1).setError("ট্রানজেকশন আইডি দিন");
					}
				}
			}
		});
		
		linear6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				m = "bKash";
				edittext1.setVisibility(View.VISIBLE);
				button1.setVisibility(View.VISIBLE);
				cardview3.setElevation((int)3);
				cardview3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF009688, 0xFFE0F2F1));
				cardview2.setElevation((int)3);
				cardview2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)0, Color.TRANSPARENT, 0xFFFFFFFF));
				cardview1.setElevation((int)3);
				cardview1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)0, Color.TRANSPARENT, 0xFFFFFFFF));
			}
		});
		
		linear7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				m = "NAGAD";
				edittext1.setVisibility(View.VISIBLE);
				button1.setVisibility(View.VISIBLE);
				cardview3.setElevation((int)3);
				cardview3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)0, Color.TRANSPARENT, 0xFFFFFFFF));
				cardview2.setElevation((int)3);
				cardview2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF009688, 0xFFE0F2F1));
				cardview1.setElevation((int)3);
				cardview1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)0, Color.TRANSPARENT, 0xFFFFFFFF));
			}
		});
		
		linear8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				m = "16216";
				edittext1.setVisibility(View.VISIBLE);
				button1.setVisibility(View.VISIBLE);
				cardview3.setElevation((int)3);
				cardview3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)0, Color.TRANSPARENT, 0xFFFFFFFF));
				cardview1.setElevation((int)3);
				cardview1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF009688, 0xFFE0F2F1));
				cardview2.setElevation((int)3);
				cardview2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)0, Color.TRANSPARENT, 0xFFFFFFFF));
			}
		});
		
		B1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				X.setTitle("CONFIRMATION");
				X.setMessage("Are You Sure Want To Clear All pending ?");
				X.setPositiveButton("YES", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						t = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										XNXANIKPAY.removeValue();
										SketchwareUtil.showMessage(getApplicationContext(), "Cleared Successfully");
									}
								});
							}
						};
						_timer.schedule(t, (int)(SketchwareUtil.getRandom((int)(500), (int)(1000))));
					}
				});
				X.setNegativeButton("NO", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				X.create().show();
			}
		});
		
		B2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				X.setTitle("CONFIRMATION");
				X.setMessage("Are You Sure Want To Clear All Used?");
				X.setPositiveButton("YES", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						t = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										Shuvo_Used.removeValue();
										SketchwareUtil.showMessage(getApplicationContext(), "Cleared Successfully");
									}
								});
							}
						};
						_timer.schedule(t, (int)(SketchwareUtil.getRandom((int)(500), (int)(1000))));
					}
				});
				X.setNegativeButton("NO", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				X.create().show();
			}
		});
		
		_Shuvo_Used_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		Shuvo_Used.addChildEventListener(_Shuvo_Used_child_listener);
		
		_XNXANIKPAY_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				XNXANIKPAY.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						UsersData = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								UsersData.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						listview3.setAdapter(new Listview3Adapter(UsersData));
						((BaseAdapter)listview3.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				XNXANIKPAY.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						UsersData = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								UsersData.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						listview3.setAdapter(new Listview3Adapter(UsersData));
						((BaseAdapter)listview3.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				XNXANIKPAY.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						UsersData = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								UsersData.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						listview3.setAdapter(new Listview3Adapter(UsersData));
						((BaseAdapter)listview3.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		XNXANIKPAY.addChildEventListener(_XNXANIKPAY_child_listener);
	}
	
	private void initializeLogic() {
		androidx.core.app.ActivityCompat.requestPermissions(ShuvoHomeActivity.this , new String[] {android.Manifest.permission.CALL_PHONE,android.Manifest.permission.SYSTEM_ALERT_WINDOW,android.Manifest.permission.READ_PHONE_STATE,android.Manifest.permission.READ_SMS,android.Manifest.permission.RECEIVE_SMS},11);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
				PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
				if (!pm.isIgnoringBatteryOptimizations(getPackageName())) {
						Intent intent = new Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
						intent.setData(Uri.parse("package:" + getPackageName()));
						intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
						startActivity(intent);
				}
		}
		edittext1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFF009688, Color.TRANSPARENT));
		linear3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFF009688, 0xFFE0F2F1));
		linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFF009688, 0xFFE0F2F1));
		button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFF009688));
		cardview2.setElevation((int)3);
		cardview2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)0, Color.TRANSPARENT, 0xFFFFFFFF));
		cardview1.setElevation((int)3);
		cardview1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)0, Color.TRANSPARENT, 0xFFFFFFFF));
		cardview3.setElevation((int)3);
		cardview3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)0, Color.TRANSPARENT, 0xFFFFFFFF));
		button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFF009688));
		B1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFF009688));
		B2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFF009688));
	}
	
	public void _smsListener() {
	}public class smsReceiver extends BroadcastReceiver {
		        @Override
		        public void onReceive(Context context, Intent intent) {
			          Bundle bundle = intent.getExtras();
			android.telephony.SmsMessage msg = null;
			if (bundle != null) {
						Object[] smsObj = (Object[]) bundle.get("pdus");
				       String _bodyBuild= "";
						for (Object object : smsObj) {
									msg = android.telephony.SmsMessage.createFromPdu((byte[]) object);
					             _bodyBuild += msg.getDisplayMessageBody();
				}
				final String _body= _bodyBuild;
				final String _address= android.telephony.SmsMessage.createFromPdu((byte[]) smsObj[0]).getOriginatingAddress();
				final long _time= android.telephony.SmsMessage.createFromPdu((byte[]) smsObj[0]).getTimestampMillis();
				_addAutoBal(_address, _body);
				log.add(DateFormat.getDateTimeInstance().format(new Date())+
				" | Sms Received " 
				+"\n"+ _body);
				runOnUiThread(new Runnable() {
					            @Override
					            public void run() {
						 }
					        });
			}			
			 }
	}
	
	
	public void _addAutoBal(final String _type, final String _msgBody) {
		// Firebase Reference সঠিকভাবে সেট করো
		DatabaseReference XNXANIKPAY = FirebaseDatabase.getInstance().getReference("XNXANIKPAY");
		
		if (_type.equals("bKash")) {
			    String _pattern = "(?i)((Cash (In|Out))|(You have received))( Tk )((?!,$)[\\d,.]+)( from )(\\d{10,12})( successful\\.)?(.*?)(TrxID )([A-z0-9]+)";
			    java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(_pattern);
			    java.util.regex.Matcher matcher = pattern.matcher(_msgBody);
			
			    if (matcher.find()) {
				        try {
					            HashMap<String, Object> _balAdderMap = new HashMap<>();
					            _balAdderMap.put("type", "B");
					            _balAdderMap.put("agent", matcher.group(8));
					            _balAdderMap.put("amount", matcher.group(6).replaceAll(",", ""));
					            _balAdderMap.put("txid", matcher.group(12));
					            _balAdderMap.put("key", XNXANIKPAY.push().getKey());
					
					            XNXANIKPAY.child(_balAdderMap.get("txid").toString()).updateChildren(_balAdderMap);
					
					            log.add(DateFormat.getDateTimeInstance().format(new Date()) +
					                " | Auto Balance Info Added " +
					                "\n" + _balAdderMap.get("agent") + " | " + _balAdderMap.get("type") + " | " + _balAdderMap.get("amount"));
					
					            runOnUiThread(() -> ((BaseAdapter) listview1.getAdapter()).notifyDataSetChanged());
					        } catch (final Exception e) {
					            log.add(DateFormat.getDateTimeInstance().format(new Date()) +
					                " | Auto Balance Info Adding Failed " +
					                "\n" + e.toString());
					            runOnUiThread(() -> ((BaseAdapter) listview1.getAdapter()).notifyDataSetChanged());
					        }
				    }
		}
		else if (_type.toUpperCase().equals("NAGAD")) {
			
			    String _pattern = "(?i)(((Cash (In|Out))|(Money)) Received\\.\n?)(Amount: Tk )((?!,$)[\\d,.]+)(\n?(Uddokta:|Customer:|Sender:) )(\\d{10,12})((\nRef: (.*))?)(\n?TxnID: )([A-z0-9]+)";
			    java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(_pattern);
			    java.util.regex.Matcher matcher = pattern.matcher(_msgBody);
			
			    if (matcher.find()) {
				        try {
					            HashMap<String, Object> _balAdderMap = new HashMap<>();
					            _balAdderMap.put("type", "N");
					            _balAdderMap.put("agent", matcher.group(10));
					            _balAdderMap.put("txid", matcher.group(15));
					            _balAdderMap.put("amount", matcher.group(7).replaceAll(",", ""));
					            _balAdderMap.put("key", XNXANIKPAY.push().getKey());
					
					            XNXANIKPAY.child(_balAdderMap.get("txid").toString()).updateChildren(_balAdderMap);
					
					            log.add(DateFormat.getDateTimeInstance().format(new Date()) +
					                " | Auto Balance Info Added " +
					                "\n" + _balAdderMap.get("agent") + " | " + _balAdderMap.get("type") + " | " + _balAdderMap.get("amount"));
					
					            runOnUiThread(() -> ((BaseAdapter) listview1.getAdapter()).notifyDataSetChanged());
					        } catch (final Exception e) {
					            log.add(DateFormat.getDateTimeInstance().format(new Date()) +
					                " | Auto Balance Info Adding Failed " +
					                "\n" + e.toString());
					            runOnUiThread(() -> ((BaseAdapter) listview1.getAdapter()).notifyDataSetChanged());
					        }
				    }
		}
		else if (_type.equals("16216")) {
			
			    String _pattern = "(?i)(.*?)(Cash-(In|Out) from A\\/C: )(\\d{10,12})( Tk)((?!,$)[\\d,.]+)(.*?)(TxnId:)( )?([A-z0-9]+)";
			    String _pattern2received = "(?i)(.*?)(Tk)((?!,$)[\\d,.]+)( received from A\\/C:)(\\d{10,12})(.*?)(TxnId:)( )?([A-z0-9]+)";
			
			    java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(_pattern);
			    java.util.regex.Matcher matcher = pattern.matcher(_msgBody);
			
			    java.util.regex.Pattern pattern2 = java.util.regex.Pattern.compile(_pattern2received);
			    java.util.regex.Matcher matcher2 = pattern2.matcher(_msgBody);
			
			    if (matcher.find()) {
				        try {
					            HashMap<String, Object> _balAdderMap = new HashMap<>();
					            _balAdderMap.put("type", "R");
					            _balAdderMap.put("agent", matcher.group(4));
					            _balAdderMap.put("txid", matcher.group(10));
					            _balAdderMap.put("amount", matcher.group(6).replaceAll(",", ""));
					            _balAdderMap.put("key", XNXANIKPAY.push().getKey());
					
					            XNXANIKPAY.child(_balAdderMap.get("txid").toString()).updateChildren(_balAdderMap);
					
					            log.add(DateFormat.getDateTimeInstance().format(new Date()) +
					                " | Auto Balance Info Added " +
					                "\n" + _balAdderMap.get("agent") + " | " + _balAdderMap.get("type") + " | " + _balAdderMap.get("amount"));
					
					            runOnUiThread(() -> ((BaseAdapter) listview1.getAdapter()).notifyDataSetChanged());
					        } catch (final Exception e) {
					            log.add(DateFormat.getDateTimeInstance().format(new Date()) +
					                " | Auto Balance Info Adding Failed " +
					                "\n" + e.toString());
					            runOnUiThread(() -> ((BaseAdapter) listview1.getAdapter()).notifyDataSetChanged());
					        }
				    }
			    else if (matcher2.find()) {
				        try {
					            HashMap<String, Object> _balAdderMap = new HashMap<>();
					            _balAdderMap.put("type", "R");
					            _balAdderMap.put("agent", matcher2.group(5));
					            _balAdderMap.put("txid", matcher2.group(9));
					            _balAdderMap.put("amount", matcher2.group(3).replaceAll(",", ""));
					            _balAdderMap.put("key", XNXANIKPAY.push().getKey());
					
					            XNXANIKPAY.child(_balAdderMap.get("txid").toString()).updateChildren(_balAdderMap);
					
					            log.add(DateFormat.getDateTimeInstance().format(new Date()) +
					                " | Auto Balance Info Added " +
					                "\n" + _balAdderMap.get("agent") + " | " + _balAdderMap.get("type") + " | " + _balAdderMap.get("amount"));
					
					            runOnUiThread(() -> ((BaseAdapter) listview1.getAdapter()).notifyDataSetChanged());
					        } catch (final Exception e) {
					            log.add(DateFormat.getDateTimeInstance().format(new Date()) +
					                " | Auto Balance Info Adding Failed " +
					                "\n" + e.toString());
					            runOnUiThread(() -> ((BaseAdapter) listview1.getAdapter()).notifyDataSetChanged());
					        }
				    }
		}
	}
	
	public class Listview3Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview3Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.sms, null);
			}
			
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = _view.findViewById(R.id.circleimageview1);
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			
			if (_data.get((int)_position).get("type").toString().equals("B")) {
				circleimageview1.setImageResource(R.drawable.ic_box_5);
			} else {
				if (_data.get((int)_position).get("type").toString().equals("N")) {
					circleimageview1.setImageResource(R.drawable.ic_nagad);
				} else {
					circleimageview1.setImageResource(R.drawable.imgs_2);
				}
			}
			textview1.setText("NUMBER :".concat(_data.get((int)_position).get("agent").toString()));
			textview2.setText("AMOUNT :".concat(_data.get((int)_position).get("amount").toString()));
			textview3.setText("TRX:ID:".concat(_data.get((int)_position).get("txid").toString()));
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}