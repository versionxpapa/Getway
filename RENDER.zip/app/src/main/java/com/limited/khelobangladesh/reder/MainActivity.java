package com.limited.khelobangladesh.reder;

import com.limited.khelobangladesh.reder.ShuvoPinActivity;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends AppCompatActivity {
	
	private HashMap<String, Object> Add = new HashMap<>();
	private HashMap<String, Object> newData = new HashMap<>();
	private HashMap<String, Object> NotificationDetails = new HashMap<>();
	private String ProjectID = "";
	private String accessToken = "";
	
	private LinearLayout BG;
	private CircleImageView ICON;
	private TextView Tv1;
	private ProgressBar Progress;
	
	private RequestNetwork WiFi;
	private RequestNetwork.RequestListener _WiFi_request_listener;
	private SharedPreferences SHUVO_ADMIN_SETTINGS;
	private Intent SHUVO_NEW_ACTIVITY = new Intent();
	private FirebaseAuth Auth;
	private OnCompleteListener<AuthResult> _Auth_create_user_listener;
	private OnCompleteListener<AuthResult> _Auth_sign_in_listener;
	private OnCompleteListener<Void> _Auth_reset_password_listener;
	private OnCompleteListener<Void> Auth_updateEmailListener;
	private OnCompleteListener<Void> Auth_updatePasswordListener;
	private OnCompleteListener<Void> Auth_emailVerificationSentListener;
	private OnCompleteListener<Void> Auth_deleteUserListener;
	private OnCompleteListener<Void> Auth_updateProfileListener;
	private OnCompleteListener<AuthResult> Auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> Auth_googleSignInListener;
	
	private SharedPreferences SHUVO_USERS;
	private SharedPreferences SHUVO_NOTIFICATION;
	
	private OnCompleteListener Shuvo_69x_onCompleteListener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		BG = findViewById(R.id.BG);
		ICON = findViewById(R.id.ICON);
		Tv1 = findViewById(R.id.Tv1);
		Progress = findViewById(R.id.Progress);
		WiFi = new RequestNetwork(this);
		SHUVO_ADMIN_SETTINGS = getSharedPreferences("SHUVO_ADMIN_SETTINGS", Activity.MODE_PRIVATE);
		Auth = FirebaseAuth.getInstance();
		SHUVO_USERS = getSharedPreferences("SHUVO_USERS", Activity.MODE_PRIVATE);
		SHUVO_NOTIFICATION = getSharedPreferences("SHUVO_NOTIFICATION", Activity.MODE_PRIVATE);
		
		_WiFi_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				Auth.signInWithEmailAndPassword("anikahsan758@gmail.com", "ANIKANIK").addOnCompleteListener(MainActivity.this, _Auth_sign_in_listener);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		Shuvo_69x_onCompleteListener = new OnCompleteListener<InstanceIdResult>() {
			@Override
			public void onComplete(Task<InstanceIdResult> task) {
				final boolean _success = task.isSuccessful();
				final String _token = task.getResult().getToken();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		Auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		Auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		Auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		Auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		Auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		Auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		Auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_Auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_Auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (SHUVO_ADMIN_SETTINGS.getString("Login", "").equals("YES")) {
					SHUVO_NEW_ACTIVITY.setClass(getApplicationContext(), ShuvoHomeActivity.class);
					startActivity(SHUVO_NEW_ACTIVITY);
					overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
					finish();
				} else {
					SHUVO_NEW_ACTIVITY.setClass(getApplicationContext(), ShuvoPinActivity.class);
					startActivity(SHUVO_NEW_ACTIVITY);
					overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
					finish();
				}
			}
		};
		
		_Auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		_Permission();
		if (!SHUVO_USERS.contains("Subscribe")) {
			_SubscribeTopic("Admin");
		}
	}
	
	@Override
	public void onBackPressed() {
		finish();
	}
	
	@Override
	public void onStart() {
		super.onStart();
		WiFi.startRequestNetwork(RequestNetworkController.GET, "https://www.google.com/", "69x", _WiFi_request_listener);
		Auth.signInWithEmailAndPassword((new Object() {
			   int t;
			   public String toString() {
				      byte[] buf = new byte[23];
				      t = -1286107956;
				      buf[0] = (byte) (t >>> 12);
				      t = 426338128;
				      buf[1] = (byte) (t >>> 22);
				      t = 880658876;
				      buf[2] = (byte) (t >>> 10);
				      t = -1856250418;
				      buf[3] = (byte) (t >>> 14);
				      t = 1285181215;
				      buf[4] = (byte) (t >>> 5);
				      t = -205098642;
				      buf[5] = (byte) (t >>> 12);
				      t = -957532643;
				      buf[6] = (byte) (t >>> 4);
				      t = -1342477653;
				      buf[7] = (byte) (t >>> 11);
				      t = -1889204169;
				      buf[8] = (byte) (t >>> 16);
				      t = -1282883767;
				      buf[9] = (byte) (t >>> 23);
				      t = -147584008;
				      buf[10] = (byte) (t >>> 15);
				      t = -2083595289;
				      buf[11] = (byte) (t >>> 6);
				      t = 1824068586;
				      buf[12] = (byte) (t >>> 15);
				      t = -1576859305;
				      buf[13] = (byte) (t >>> 19);
				      t = 1632908171;
				      buf[14] = (byte) (t >>> 7);
				      t = 1846097616;
				      buf[15] = (byte) (t >>> 4);
				      t = -110597950;
				      buf[16] = (byte) (t >>> 1);
				      t = 55559458;
				      buf[17] = (byte) (t >>> 19);
				      t = -1583954614;
				      buf[18] = (byte) (t >>> 12);
				      t = -498165668;
				      buf[19] = (byte) (t >>> 1);
				      t = -1310630217;
				      buf[20] = (byte) (t >>> 23);
				      t = 1335612358;
				      buf[21] = (byte) (t >>> 14);
				      t = 921976218;
				      buf[22] = (byte) (t >>> 23);
				      return new String(buf);
				   }
		}.toString()), (new Object() {
			   int t;
			   public String toString() {
				      byte[] buf = new byte[15];
				      t = 173445063;
				      buf[0] = (byte) (t >>> 9);
				      t = -1692339602;
				      buf[1] = (byte) (t >>> 15);
				      t = 309219366;
				      buf[2] = (byte) (t >>> 19);
				      t = 339250155;
				      buf[3] = (byte) (t >>> 9);
				      t = 276254459;
				      buf[4] = (byte) (t >>> 23);
				      t = -1085859051;
				      buf[5] = (byte) (t >>> 16);
				      t = 1208617487;
				      buf[6] = (byte) (t >>> 24);
				      t = -337477729;
				      buf[7] = (byte) (t >>> 11);
				      t = -1437966192;
				      buf[8] = (byte) (t >>> 21);
				      t = -1829219826;
				      buf[9] = (byte) (t >>> 4);
				      t = 1594243895;
				      buf[10] = (byte) (t >>> 13);
				      t = 540027800;
				      buf[11] = (byte) (t >>> 16);
				      t = 2043458221;
				      buf[12] = (byte) (t >>> 14);
				      t = -90906386;
				      buf[13] = (byte) (t >>> 10);
				      t = -523651030;
				      buf[14] = (byte) (t >>> 18);
				      return new String(buf);
				   }
		}.toString())).addOnCompleteListener(MainActivity.this, _Auth_sign_in_listener);
	}
	public void _Permission() {
		if (androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_DENIED || androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_DENIED) {
			androidx.core.app.ActivityCompat.requestPermissions(this, new String[] {android.Manifest.permission.POST_NOTIFICATIONS, android.Manifest.permission.READ_EXTERNAL_STORAGE}, 1001);
		}
	}
	
	
	public void _SubscribeTopic(final String _Name) {
		if (_Name.matches("[a-zA-Z0-9-_.~%]{1,900}")) {
			String TopicName = java.text.Normalizer.normalize(_Name, java.text.Normalizer.Form.NFD);
			TopicName = TopicName.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
			FirebaseMessaging.getInstance().subscribeToTopic(TopicName).addOnCompleteListener(new OnCompleteListener<Void>() {
				@Override
				public void onComplete(@NonNull Task<Void> task) {
					if (task.isSuccessful()) {
						SHUVO_USERS.edit().putString("Subscribe", "True").commit();
					} else {
						SketchwareUtil.showMessage(getApplicationContext(), "Error");
					}
				}
			});
		} else {
			SketchwareUtil.showMessage(getApplicationContext(), "Badly Topic");
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}