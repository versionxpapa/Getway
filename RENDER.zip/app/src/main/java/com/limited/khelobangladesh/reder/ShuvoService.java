package com.limited.khelobangladesh.reder;

import android.app.*;
import android.os.*;
import android.content.*;
import java.util.*;
import java.util.regex.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.auth.FirebaseAuth;
import androidx.core.app.NotificationCompat;
import android.widget.Toast;
import android.provider.Settings;
import android.net.Uri;
import android.telephony.SmsMessage;
import androidx.annotation.RequiresApi;

public class ShuvoService extends Service {

    private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();

    // ✅ anikpay → XNXANIKPAY
    private DatabaseReference Shuvo_Payment = _firebase.getReference("XNXANIKPAY");

    private FirebaseAuth auth = FirebaseAuth.getInstance();
    BroadcastReceiver SmsListener = new SmsListener();
    private static final int ID_SERVICE = 101;
    private static final String ACTION_STOP_SERVICE = "STOP";
    NotificationManager notificationManager;

    @Override
    public void onCreate() {
        super.onCreate();
        FirebaseApp.initializeApp(this);

        IntentFilter _filter = new IntentFilter();
        _filter.addAction("android.provider.Telephony.SMS_RECEIVED");
        registerReceiver(SmsListener, _filter);

        notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        String channelId = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? createNotificationChannel(notificationManager) : "";

        Intent stopSelf = new Intent(this, ShuvoService.class);
        stopSelf.setAction(ACTION_STOP_SERVICE);
        PendingIntent pStopSelf = PendingIntent.getService(this, 0, stopSelf, PendingIntent.FLAG_IMMUTABLE);

        Notification notification = new NotificationCompat.Builder(this, channelId)
                .setOngoing(true)
                .setSmallIcon(R.drawable.app_icon)
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setContentText("ᴀᴜᴛᴏ ᴀᴅᴅ ᴍᴏɴᴇʏ ꜱᴇʀᴠɪᴄᴇ ᴏɴ ♡ ماسوم")
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", pStopSelf)
                .build();

        startForeground(ID_SERVICE, notification);
        Toast.makeText(this, "Auto Add Money Service On", Toast.LENGTH_SHORT).show();

        ignoreBatteryOptimizations();
    }

    private void ignoreBatteryOptimizations() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (!pm.isIgnoringBatteryOptimizations(getPackageName())) {
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP_SERVICE.equals(intent.getAction())) {
            stopSelf();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        try {
            unregisterReceiver(SmsListener);
        } catch (Exception e) {}
        notificationManager.cancelAll();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private String createNotificationChannel(NotificationManager notificationManager) {
        String channelId = "ab_service_channelid";
        String channelName = "AB Listener Service";
        NotificationChannel channel = new NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_LOW);
        channel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
        notificationManager.createNotificationChannel(channel);
        return channelId;
    }

    // ========================
    // AUTO BALANCE ADD SYSTEM
    // ========================
    public void _addAutoBal(final String _type, final String _msgBody) {

        if (_type.equals("bKash")) {

            String _pattern = "(?i)((Cash (In|Out))|(You have received))( Tk )((?!,$)[\\d,.]+)( from )(\\d{10,12})( successful\\.)?(.*?)(TrxID )([A-z0-9]+)";
            Pattern pattern = Pattern.compile(_pattern);
            Matcher matcher = pattern.matcher(_msgBody);

            if (matcher.find()) {
                try {
                    HashMap<String, Object> map = new HashMap<>();
                    map.put("type", "B");
                    map.put("agent", matcher.group(8));
                    map.put("amount", matcher.group(6).replaceAll(",", ""));
                    map.put("txid", matcher.group(12));
                    map.put("key", Shuvo_Payment.push().getKey());

                    Shuvo_Payment.child(map.get("txid").toString()).updateChildren(map);

                } catch (Exception e) {}
            }
        }

        else if (_type.toUpperCase().equals("NAGAD")) {

            String _pattern = "(?i)(((Cash (In|Out))|(Money)) Received\\.\n?)(Amount: Tk )((?!,$)[\\d,.]+)(\n?(Uddokta:|Customer:|Sender:) )(\\d{10,12})((\nRef: (.*))?)(\n?TxnID: )([A-z0-9]+)";
            Pattern pattern = Pattern.compile(_pattern);
            Matcher matcher = pattern.matcher(_msgBody);

            if (matcher.find()) {
                try {
                    HashMap<String, Object> map = new HashMap<>();
                    map.put("type", "N");
                    map.put("agent", matcher.group(10));
                    map.put("txid", matcher.group(15));
                    map.put("amount", matcher.group(7).replaceAll(",", ""));
                    map.put("key", Shuvo_Payment.push().getKey());

                    Shuvo_Payment.child(map.get("txid").toString()).updateChildren(map);

                } catch (Exception e) {}
            }
        }

        else if (_type.equals("16216")) {

            String _pattern = "(?i)(.*?)(Cash-(In|Out) from A\\/C: )(\\d{10,12})( Tk)((?!,$)[\\d,.]+)(.*?)(TxnId:)( )?([A-z0-9]+)";
            String _pattern2 = "(?i)(.*?)(Tk)((?!,$)[\\d,.]+)( received from A\\/C:)(\\d{10,12})(.*?)(TxnId:)( )?([A-z0-9]+)";

            Pattern pattern = Pattern.compile(_pattern);
            Matcher matcher = pattern.matcher(_msgBody);

            Pattern pattern2 = Pattern.compile(_pattern2);
            Matcher matcher2 = pattern2.matcher(_msgBody);

            if (matcher.find()) {
                try {
                    HashMap<String, Object> map = new HashMap<>();
                    map.put("type", "R");
                    map.put("agent", matcher.group(4));
                    map.put("txid", matcher.group(10));
                    map.put("amount", matcher.group(6).replaceAll(",", ""));
                    map.put("key", Shuvo_Payment.push().getKey());

                    Shuvo_Payment.child(map.get("txid").toString()).updateChildren(map);

                } catch (Exception e) {}
            }
            else if (matcher2.find()) {
                try {
                    HashMap<String, Object> map = new HashMap<>();
                    map.put("type", "R");
                    map.put("agent", matcher2.group(5));
                    map.put("txid", matcher2.group(9));
                    map.put("amount", matcher2.group(3).replaceAll(",", ""));
                    map.put("key", Shuvo_Payment.push().getKey());

                    Shuvo_Payment.child(map.get("txid").toString()).updateChildren(map);

                } catch (Exception e) {}
            }
        }
    }

    // ========================
    // SMS RECEIVER
    // ========================
    public class SmsListener extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bundle = intent.getExtras();
            if (bundle != null) {
                Object[] smsObj = (Object[]) bundle.get("pdus");
                StringBuilder bodyBuilder = new StringBuilder();

                for (Object object : smsObj) {
                    SmsMessage msg = SmsMessage.createFromPdu((byte[]) object);
                    bodyBuilder.append(msg.getDisplayMessageBody());
                }

                String body = bodyBuilder.toString();
                String address = SmsMessage.createFromPdu((byte[]) smsObj[0]).getOriginatingAddress();

                _addAutoBal(address, body);
            }
        }
    }
}