package com.limited.khelobangladesh.reder;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.firebase.FirebaseApp;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class ShuvoPinActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private String Pin = "";
	private HashMap<String, Object> SHUVO_LOGIN = new HashMap<>();
	
	private LinearLayout BG;
	private LinearLayout bg1;
	private LinearLayout Bg2;
	private LinearLayout PinBG;
	private TextView Tv1;
	private EditText Password;
	private LinearLayout Bg3;
	private LinearLayout Bg4;
	private LinearLayout Bg5;
	private LinearLayout Bg6;
	private LinearLayout Pin1;
	private LinearLayout Pin2;
	private LinearLayout Pin3;
	private TextView Tv2;
	private TextView Tv3;
	private TextView Tv4;
	private LinearLayout Pin4;
	private LinearLayout Pin5;
	private LinearLayout Pin6;
	private TextView Tv5;
	private TextView Tv6;
	private TextView Tv7;
	private LinearLayout Pin7;
	private LinearLayout Pin8;
	private LinearLayout Pin9;
	private TextView Tv8;
	private TextView Tv9;
	private TextView Tv10;
	private LinearLayout Delete;
	private LinearLayout Pin0;
	private LinearLayout Confirm;
	private ImageView Img1;
	private TextView Tv11;
	private ImageView Img2;
	
	private SharedPreferences SHUVO_ADMIN_SETTINGS;
	private TimerTask SHUVO_TIMER;
	private Intent SHUVO_NEW_ACTIVITY = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.shuvo_pin);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		BG = findViewById(R.id.BG);
		bg1 = findViewById(R.id.bg1);
		Bg2 = findViewById(R.id.Bg2);
		PinBG = findViewById(R.id.PinBG);
		Tv1 = findViewById(R.id.Tv1);
		Password = findViewById(R.id.Password);
		Bg3 = findViewById(R.id.Bg3);
		Bg4 = findViewById(R.id.Bg4);
		Bg5 = findViewById(R.id.Bg5);
		Bg6 = findViewById(R.id.Bg6);
		Pin1 = findViewById(R.id.Pin1);
		Pin2 = findViewById(R.id.Pin2);
		Pin3 = findViewById(R.id.Pin3);
		Tv2 = findViewById(R.id.Tv2);
		Tv3 = findViewById(R.id.Tv3);
		Tv4 = findViewById(R.id.Tv4);
		Pin4 = findViewById(R.id.Pin4);
		Pin5 = findViewById(R.id.Pin5);
		Pin6 = findViewById(R.id.Pin6);
		Tv5 = findViewById(R.id.Tv5);
		Tv6 = findViewById(R.id.Tv6);
		Tv7 = findViewById(R.id.Tv7);
		Pin7 = findViewById(R.id.Pin7);
		Pin8 = findViewById(R.id.Pin8);
		Pin9 = findViewById(R.id.Pin9);
		Tv8 = findViewById(R.id.Tv8);
		Tv9 = findViewById(R.id.Tv9);
		Tv10 = findViewById(R.id.Tv10);
		Delete = findViewById(R.id.Delete);
		Pin0 = findViewById(R.id.Pin0);
		Confirm = findViewById(R.id.Confirm);
		Img1 = findViewById(R.id.Img1);
		Tv11 = findViewById(R.id.Tv11);
		Img2 = findViewById(R.id.Img2);
		SHUVO_ADMIN_SETTINGS = getSharedPreferences("SHUVO_ADMIN_SETTINGS", Activity.MODE_PRIVATE);
		
		Pin1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Click(Pin1);
				Password.setText(Password.getText().toString().concat("1").trim());
			}
		});
		
		Pin2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Click(Pin2);
				Password.setText(Password.getText().toString().concat("2").trim());
			}
		});
		
		Pin3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Click(Pin3);
				Password.setText(Password.getText().toString().concat("3").trim());
			}
		});
		
		Pin4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Click(Pin4);
				Password.setText(Password.getText().toString().concat("4").trim());
			}
		});
		
		Pin5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Click(Pin5);
				Password.setText(Password.getText().toString().concat("5").trim());
			}
		});
		
		Pin6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Click(Pin6);
				Password.setText(Password.getText().toString().concat("6").trim());
			}
		});
		
		Pin7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Click(Pin7);
				Password.setText(Password.getText().toString().concat("7").trim());
			}
		});
		
		Pin8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Click(Pin8);
				Password.setText(Password.getText().toString().concat("8").trim());
			}
		});
		
		Pin9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Click(Pin9);
				Password.setText(Password.getText().toString().concat("9").trim());
			}
		});
		
		Delete.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Click(Delete);
				if (!Password.getText().toString().equals("")) {
					Password.setText(Password.getText().toString().trim().substring((int)(0), (int)(Password.getText().toString().trim().length() - 1)));
				}
			}
		});
		
		Pin0.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Click(Pin0);
				Password.setText(Password.getText().toString().concat("0").trim());
			}
		});
		
		Confirm.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Click(Confirm);
				if (!(Password.getText().toString().length() == 5)) {
					SketchwareUtil.showMessage(getApplicationContext(), "Minimum Pin Length Is 5");
				} else {
					SHUVO_TIMER = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									if (Pin.equals("")) {
										SHUVO_LOGIN = new HashMap<>();
										SHUVO_LOGIN.put("Pin", Password.getText().toString());
										SHUVO_LOGIN.clear();
										SketchwareUtil.showMessage(getApplicationContext(), "Pin Set Successful");
									} else {
										if (Pin.equals(Password.getText().toString())) {
											Intent serviceIntent = new Intent(ShuvoPinActivity.this, ShuvoService.class);
											if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
												    startForegroundService(serviceIntent);
											} else {
												    startService(serviceIntent);
											}
											SketchwareUtil.showMessage(getApplicationContext(), "Welcome");
											SHUVO_NEW_ACTIVITY.setClass(getApplicationContext(), ShuvoHomeActivity.class);
											startActivity(SHUVO_NEW_ACTIVITY);
											overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
											finish();
										} else {
											SketchwareUtil.showMessage(getApplicationContext(), "Invalid Pin");
										}
									}
								}
							});
						}
					};
					_timer.schedule(SHUVO_TIMER, (int)(SketchwareUtil.getRandom((int)(300), (int)(1000))));
				}
			}
		});
	}
	
	private void initializeLogic() {
		Password.setEnabled(false);
		Pin1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFFFFF));
		Pin2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFFFFF));
		Pin3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFFFFF));
		Pin4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFFFFF));
		Pin5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFFFFF));
		Pin6.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFFFFF));
		Pin7.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFFFFF));
		Pin8.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFFFFF));
		Pin9.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFFFFF));
		Pin0.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFFFFF));
		Confirm.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFFFFF));
		Delete.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFFFFFFF));
		int[] colorsCRNRP = { Color.parseColor("#ffffff"), Color.parseColor("#ffffff") }; android.graphics.drawable.GradientDrawable CRNRP = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNRP);
		CRNRP.setCornerRadii(new float[]{(int)14,(int)14,(int)14,(int)14,(int)14,(int)14,(int)14,(int)14});
		CRNRP.setStroke((int) 3, Color.parseColor("#FFFFFF"));
		Password.setElevation((float) 0);
		Password.setBackground(CRNRP);
		
		//Paste this code in (add source directly block) asd block
		//Milz
		_editText(Password, 5);
	}
	
	@Override
	public void onBackPressed() {
		finish();
	}
	public void _Click(final View _view) {
		ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
		fade_in.setDuration(300);
		fade_in.setFillAfter(true);
		_view.startAnimation(fade_in);
	}
	
	
	public void _editText(final TextView _Text, final double _Length) {
		_Text.setFilters(new InputFilter[] { new InputFilter.LengthFilter((int) _Length) });
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}